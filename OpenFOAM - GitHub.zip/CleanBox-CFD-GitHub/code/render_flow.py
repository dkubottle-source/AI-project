#!/usr/bin/env pvpython
"""pvpython render_paraview.py CASE --output NEW_FOLDER [--fps 10]."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
from common import load,scheduled_times

SPEED_COLORS = [(0.0, (0.12, 0.25, 0.8)), (0.25, (0.0, 0.7, 0.85)),
                (0.5, (0.3, 0.8, 0.3)), (0.75, (1.0, 0.75, 0.05)),
                (1.0, (0.85, 0.08, 0.05))]


def speed_color(value, maximum):
    ratio = max(0.0, min(1.0, value / maximum))
    for (lo, a), (hi, b) in zip(SPEED_COLORS, SPEED_COLORS[1:]):
        if ratio <= hi:
            f = (ratio-lo)/(hi-lo)
            return [x+f*(y-x) for x,y in zip(a,b)]
    return list(SPEED_COLORS[-1][1])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('case', type=Path)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--fps', type=int, default=10)
    p.add_argument('--snapshot', action='store_true')
    p.add_argument('--review-label', default='', help='Visible review limitation on every frame')
    p.add_argument('--recovery', action='store_true', help='Animate saved temperature and velocity fields; no illustrative moving markers')
    p.add_argument('--speed-max', type=float, default=2.5, help='Shared speed color scale maximum, m/s')
    p.add_argument('--tmin-c', type=float, default=25)
    p.add_argument('--tmax-c', type=float, default=35)
    p.add_argument('--slow-speed', type=float, default=0.02, help='Low-speed candidate threshold in m/s')
    a = p.parse_args()
    if a.fps <= 0 or a.tmax_c <= a.tmin_c or not 0 < a.speed_max < float('inf'):
        p.error('fps must be positive; tmax-c must exceed tmin-c')
    case = a.case.resolve()
    if not (case/'constant/polyMesh').is_dir():
        p.error('case must contain constant/polyMesh')
    if a.output.exists():
        p.error('output exists; choose a new folder')
    try:
        from paraview.simple import (OpenFOAMReader, CellDatatoPointData, Calculator,
            CreateView, Show, ColorBy, GetColorTransferFunction, GetScalarBar,
            Slice, Glyph, Text, Render, SaveScreenshot, SaveState,
            StreamTracer, Threshold, Sphere, ExtractSurface, FeatureEdges, ParticleTracer, PointSource, MergeBlocks)
    except ModuleNotFoundError as exc:
        if exc.name not in ('paraview', 'paraview.simple'):
            raise
        import sys
        raise SystemExit(
            'ParaView Python module unavailable.\n'
            f'Interpreter: {sys.executable}\n'
            'Check: type -a pvpython\n'
            'Test the resolved pvpython executable with PYTHONHOME and '
            'PYTHONPATH unset. No output folder has been created.'
        ) from None
    out = a.output.resolve()
    out.mkdir(parents=True)
    marker = case/'case.foam'
    marker.touch(exist_ok=True)
    from foam_reader import open_volume
    reader = open_volume(marker, ['T', 'U'])
    times = scheduled_times(reader.TimestepValues,load(case/'case.json'))
    if not times:
        raise RuntimeError('No saved timesteps found')
    reader.UpdatePipeline(time=times[-1])
    points = CellDatatoPointData(Input=reader)
    speed = Calculator(Input=points)
    speed.ResultArrayName = 'Speed_m_s'
    speed.Function = 'mag(U)'
    temp = Calculator(Input=speed)
    temp.ResultArrayName = 'Temperature_C'
    temp.Function = 'T - 273.15'
    temp.UpdatePipeline(time=times[-1])
    bounds = temp.GetDataInformation().GetBounds()
    center = [(bounds[2*i]+bounds[2*i+1])/2 for i in range(3)]
    length = max(bounds[2*i+1]-bounds[2*i] for i in range(3))
    view = CreateView('RenderView')
    view.ViewSize = [1600, 1000]
    view.Background = [1, 1, 1]
    if 'UseColorPaletteForBackground' in view.ListProperties(): view.UseColorPaletteForBackground = 0
    skin = ExtractSurface(Input=temp)
    edges = FeatureEdges(Input=skin)
    edges.BoundaryEdges = 1
    edges.FeatureEdges = 1
    edges.NonManifoldEdges = 0
    edges.ManifoldEdges = 0
    edge_display = Show(edges, view)
    edge_display.ColorArrayName = ["POINTS", ""]
    edge_display.DiffuseColor = [0.15, 0.15, 0.15]
    edge_display.LineWidth = 1.5
    lut = GetColorTransferFunction('Temperature_C')
    lut.RescaleTransferFunction(a.tmin_c, a.tmax_c)
    lut.RGBPoints = [a.tmin_c, 0.12, 0.35, 0.85,
                     (a.tmin_c+a.tmax_c)/2, 0.95, 0.95, 0.85,
                     a.tmax_c, 0.85, 0.12, 0.08]
    bar = GetScalarBar(lut, view)
    bar.Title = 'Air temperature'
    bar.ComponentTitle = 'deg C'
    bar.TitleColor = [0,0,0]
    bar.LabelColor = [0,0,0]
    bar.WindowLocation = 'Any Location'
    bar.Orientation = 'Horizontal'
    bar.Position = [0.08, 0.06]
    bar.ScalarBarLength = 0.30
    speed_lut = GetColorTransferFunction('Speed_m_s')
    speed_lut.ColorSpace = 'RGB'
    speed_lut.RGBPoints = [v for fraction,rgb in SPEED_COLORS for v in (fraction*a.speed_max,*rgb)]
    speed_bar = GetScalarBar(speed_lut,view)
    speed_bar.Title = 'Air speed'
    speed_bar.ComponentTitle = 'm/s'
    speed_bar.TitleColor = [0,0,0]
    speed_bar.LabelColor = [0,0,0]
    speed_bar.WindowLocation = 'Any Location'
    speed_bar.Position = [0.87,0.25]
    speed_bar.ScalarBarLength = 0.45
    def color_flow(display, opacity=0.8):
        ColorBy(display,('POINTS','Speed_m_s'))
        display.LookupTable = speed_lut
        display.LineWidth = 1.5
        display.Opacity = opacity
        display.SetScalarBarVisibility(view,True)
    # Five horizontal planes, away from the floor and lid.
    slice_heights = [bounds[4]+(bounds[5]-bounds[4])*f for f in (0.125,0.3125,0.5,0.6875,0.875)]
    cuts = []
    for height in slice_heights:
        cut = Slice(Input=temp)
        cut.SliceType = 'Plane'
        cut.SliceType.Origin = [center[0],center[1],height]
        cut.SliceType.Normal = [0,0,1]
        plane = Show(cut,view)
        plane.Representation = 'Surface'
        ColorBy(plane,('POINTS','Temperature_C'))
        plane.SetScalarBarVisibility(view,True)
        plane.Opacity = 0.35 if a.recovery else 0.08
        cuts.append(cut)
    production_config = json.loads((case/'case.json').read_text())
    from paraview import servermanager
    import math, bisect
    frozen_time = times[-1]
    view.ViewTime = frozen_time
    streams = StreamTracer(Input=temp, SeedType='Point Cloud')
    streams.Vectors = ['POINTS','U']
    streams.SeedType.Center = [p+0.015*n for p,n in zip(production_config['inlet_center'],production_config['inlet_normal'])]
    streams.SeedType.Radius = 0.008
    streams.SeedType.NumberOfPoints = 16
    streams.IntegrationDirection = 'FORWARD'
    streams.MaximumStreamlineLength = length*20
    streams.MaximumSteps = 20000
    streams.UpdatePipeline(time=frozen_time)
    sd = Show(streams,view)
    color_flow(sd)
    dataset = servermanager.Fetch(streams)
    paths = []
    diagnostics = []
    group = 'inlet_forward'
    reverse = False
    def collect(data):
        if data.IsA('vtkMultiBlockDataSet'):
            for k in range(data.GetNumberOfBlocks()):
                block=data.GetBlock(k)
                if block: collect(block)
            return
        for k in range(data.GetNumberOfCells()):
            cell=data.GetCell(k)
            if cell.GetCellDimension()!=1 or cell.GetNumberOfPoints()<2: continue
            pts=[data.GetPoint(cell.GetPointId(j)) for j in range(cell.GetNumberOfPoints())]
            values=data.GetPointData().GetArray('Speed_m_s')
            if values is None:
                raise RuntimeError('Streamlines lack Speed_m_s; cannot color markers correctly')
            speeds=[values.GetTuple1(cell.GetPointId(j)) for j in range(cell.GetNumberOfPoints())]
            reason=data.GetCellData().GetArray('ReasonForTermination')
            diagnostics.append({'group':group,'points':len(pts),
                'termination_code':reason.GetTuple1(k) if reason else None,
                'integration_start':pts[0],'integration_end':pts[-1]})
            if reverse:
                pts.reverse()  # Backward integration, forward-flow marker motion.
                speeds.reverse()
            distances=[0.0]
            for p,q in zip(pts,pts[1:]):distances.append(distances[-1]+math.sqrt(sum((x-y)**2 for x,y in zip(p,q))))
            if distances[-1]>0.02: paths.append((pts,distances,speeds))
    collect(dataset)
    # Seed the interior independently: inlet-only lines omit isolated circulation.
    for group, seed_center, radius, number, direction in [
        ('interior_forward',center,0.10,12,'FORWARD'),
    ]:
        extra=StreamTracer(Input=temp,SeedType='Point Cloud')
        extra.Vectors=['POINTS','U']
        extra.SeedType.Center=seed_center
        extra.SeedType.Radius=radius
        extra.SeedType.NumberOfPoints=number
        extra.IntegrationDirection=direction
        extra.MaximumStreamlineLength=length*12
        extra.MaximumSteps=20000
        extra.UpdatePipeline(time=frozen_time)
        ed=Show(extra,view)
        color_flow(ed,0.45)
        collect(servermanager.Fetch(extra))
    # Trace upstream from the actual outlet to reveal which paths feed the exit.
    outlet_reader=OpenFOAMReader(FileName=str(marker))
    outlet_reader.UpdatePipelineInformation()
    outlet_names=[r for r in outlet_reader.MeshRegions.Available if r=='outlet' or r.endswith('/outlet')]
    if outlet_names:
        outlet_reader.MeshRegions=outlet_names
        outlet_reader.UpdatePipeline(time=frozen_time)
        ob=outlet_reader.GetDataInformation().GetBounds()
        oc=[(ob[2*j]+ob[2*j+1])/2 for j in range(3)]
        ni=production_config['inlet_normal']
        oc=[oc[0]-0.012*ni[0],oc[1],oc[2]+0.012*ni[2]]
        exit_stream=StreamTracer(Input=temp,SeedType='Point Cloud')
        exit_stream.Vectors=['POINTS','U']
        exit_stream.SeedType.Center=oc
        exit_stream.SeedType.Radius=0.006
        exit_stream.SeedType.NumberOfPoints=10
        exit_stream.IntegrationDirection='BACKWARD'
        exit_stream.MaximumStreamlineLength=length*20
        exit_stream.MaximumSteps=20000
        exit_stream.UpdatePipeline(time=frozen_time)
        xd=Show(exit_stream,view)
        color_flow(xd,0.65)
        group='outlet_backward';reverse=True
        collect(servermanager.Fetch(exit_stream))
    (out/'streamline_diagnostics.json').write_text(json.dumps(diagnostics,indent=2))
    if not paths and not a.recovery: raise RuntimeError('No usable CFD streamlines; motion video not generated')
    movers=[]
    for index,(pts,distances,speeds) in enumerate([] if a.recovery else paths):
        ball=Sphere();ball.Radius=0.0025;ball.Center=pts[0]
        display=Show(ball,view)
        display.ColorArrayName=['POINTS','']
        display.DiffuseColor=speed_color(speeds[0],a.speed_max)
        movers.append((ball,display,pts,distances,speeds,index*0.037))
    # Patch markers from actual boundary geometry, not assumed opening positions.
    ports = OpenFOAMReader(FileName=str(marker))
    ports.UpdatePipelineInformation()
    available = list(ports.MeshRegions.Available)
    for name, color in [('inlet',[0.0,0.65,0.1]),('outlet',[0.9,0.1,0.05])]:
        matches = [r for r in available if r == name or r.endswith('/'+name)]
        if not matches: continue
        patch_reader = OpenFOAMReader(FileName=str(marker))
        patch_reader.MeshRegions = matches
        patch_reader.UpdatePipeline(time=times[-1])
        patch_display = Show(patch_reader, view)
        patch_display.ColorArrayName = ['POINTS', '']
        patch_display.DiffuseColor = color
    # Read the actual case probes rather than assuming the drawing coordinates.
    import re
    control = (case/'system/controlDict').read_text()
    match = re.search(r'probeLocations\s*\((.*?)\)\s*;', control, re.S)
    if not match:
        raise RuntimeError('probeLocations missing: cannot place sensor markers')
    locations = [tuple(map(float, xyz.split())) for xyz in
                 re.findall(r'\(([^()]*)\)', match.group(1))]
    for index, xyz in enumerate(locations, 1):
        sensor = Sphere()
        sensor.Center = xyz
        sensor.Radius = length*0.012
        sensor_display = Show(sensor, view)
        sensor_display.DiffuseColor = [0.1, 1.0, 0.8]
    view.CameraFocalPoint = center
    view.CameraPosition = [center[0]+length*1.15,
                           center[1]-length*2.0, center[2]+length*0.75]
    view.CameraViewUp = [0, 0, 1]
    view.CameraParallelProjection = 1
    view.CameraParallelScale = length*0.65
    title = Text()
    title_display = Show(title, view)
    title_display.FontSize = 16
    title_display.Color = [0,0,0]
    # Frozen final CFD field. Moving markers show direction, not physical travel time.
    manifest=[]
    frame_times = ([times[-1]] if a.snapshot else times) if a.recovery else [frozen_time]*(1 if a.snapshot else 160)
    count=len(frame_times)
    for i in range(count):
        field_time=frame_times[i]
        view.ViewTime=field_time
        temp.UpdatePipeline(time=field_time)
        phase=i/160
        for ball,display,pts,distances,speeds,offset in movers:
            distance=((phase+offset)%1)*distances[-1]
            j=min(bisect.bisect_right(distances,distance)-1,len(pts)-2)
            fraction=(distance-distances[j])/max(distances[j+1]-distances[j],1e-15)
            ball.Center=[pts[j][k]+fraction*(pts[j+1][k]-pts[j][k]) for k in range(3)]
            display.DiffuseColor=speed_color(speeds[j]+fraction*(speeds[j+1]-speeds[j]),a.speed_max)
        title.Text=(f'{case.name} | Assumed flow | Virtual probes | CFD field frozen at t={frozen_time:g}s\n'
                    'Line / marker color: CFD speed (m/s) | marker motion: direction only, not physical travel time')
        if a.recovery:
            title.Text=(f'{case.name} | Assumed flow | Virtual probes | Saved CFD time t={field_time:g}s\n'
                        '5 temperature slices: deg C | Streamlines: instantaneous CFD speed (m/s), not particle paths')
        if a.review_label:title.Text+='\n'+a.review_label
        for cut in cuts:cut.UpdatePipeline(time=field_time)
        lut.RescaleTransferFunction(a.tmin_c,a.tmax_c)
        speed_lut.RescaleTransferFunction(0,a.speed_max)
        Render(view)
        frame=f'frame_{i:05d}.png'
        SaveScreenshot(str(out/frame),view,ImageResolution=[1600,1000])
        manifest.append({'frame':frame,'CFD_time_s':field_time,'mode':'saved_time_recovery' if a.recovery else 'frozen_flow_motion','display_phase':None if a.recovery else phase})
        if i%20==0: print(f'Motion frame {i+1}/{count}; {len(paths)} CFD lines',flush=True)
    SaveState(str(out/'cleanbox.pvsm'))
    (out/'frames.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    (out/'README.txt').write_text(
        ('Saved temperature and velocity fields advance together. Streamlines are instantaneous, not particle paths.\n'
         'One frame per available saved time; see frames.json. Missing initial time is not synthesized.\n'
         'streamline_diagnostics.json describes the final field only.\n' if a.recovery else
         'Final saved CFD field is frozen. Markers move along calculated streamlines.\n')+
        'Marker motion is illustrative: not particle tracking, not physical speed or residence time.\n'
        f'Line and marker colors encode CFD speed, fixed scale 0 to {a.speed_max:g} m/s; larger values saturate.\n'
        'Paths may terminate before the outlet due to integration limits; no artificial connection is added.\n',encoding='utf-8')
    ffmpeg = shutil.which('ffmpeg')
    if ffmpeg and not a.snapshot:
        subprocess.run([ffmpeg, '-n', '-framerate', str(a.fps), '-i',
            str(out/'frame_%05d.png'), '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
            '-crf', '23', '-movflags', '+faststart',
            str(out/('temperature_recovery.mp4' if a.recovery else 'airflow_motion.mp4'))], check=True)
    else:
        print('PNG and ParaView state saved; MP4 skipped (snapshot or missing ffmpeg).')
    print('Finished:', out)


if __name__ == '__main__':
    main()
