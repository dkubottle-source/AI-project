"""Encode and verify a library asset; existing outputs never overwritten."""
import argparse
import shutil
import subprocess
import os
import secrets
from datetime import datetime
from pathlib import Path
from common import load,dump,require,verify,require_screen

def main():
    p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--root',type=Path,required=True);p.add_argument('--snapshot',action='store_true');p.add_argument('--variant',choices=['readable_v2','slices5_v3','combined_v4','fixed_v5','motion_v6','motion_v7','ports_v8','ports_v9','ports_v10','ports_v11']);a=p.parse_args()
    verify(a.case);m=load(a.case/'case.json');c=m['config'];cid=m['case_id'];out=a.root/'library'/cid
    if a.variant:out=a.root/'library'/a.variant/cid
    fps=20 if a.variant in ('motion_v6','motion_v7','ports_v8','ports_v9','ports_v10','ports_v11') else 3 if a.variant=='fixed_v5' else c['visualization']['fps']
    summary=load(a.root/'csv'/f'{cid}_summary.json')
    if not a.snapshot:require_screen(summary,m,baseline=m['physics']=='BASE' and not m['pilot'])
    if a.snapshot:out=out/'snapshot'
    require(not (out/'frames.json').exists(),'Already rendered; preserve existing asset or choose a new run root')
    # renderer requires non-existing output. Snapshot is an independently named child.
    if out.exists():require(all((x.is_file() and x.name.startswith('xvfb_') and x.suffix=='.log') or (x.is_dir() and (x.name=='snapshot' or x.name=='render' or x.name.startswith('render_retry_'))) for x in out.iterdir()),'Output contains files; inspect existing run before retry')
    if not a.snapshot:
        require(shutil.which('ffmpeg') and shutil.which('ffprobe'),'Install ffmpeg (includes ffprobe) before full rendering')
    work=out/'render'
    if work.exists() and any(work.iterdir()):
        work=out/('render_retry_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    require(not work.exists() or (m['physics']=='SMOKE' and work.is_dir() and not any(work.iterdir())),'Partial rendering exists; inspect it before restarting')
    cmd=['pvpython',str(Path(__file__).with_name('render_smoke.py' if m['physics']=='SMOKE' else 'render_flow.py')),str(a.case),'--output',str(work)]
    if a.variant=='slices5_v3':
        require(m['physics']=='SMOKE','slices5_v3 requires SMOKE')
        cmd[1]=str(Path(__file__).with_name('render_smoke_slices5.py'))
    if a.variant in ('motion_v6','motion_v7','ports_v8','ports_v9','ports_v10','ports_v11'):
        require(m['physics']=='SMOKE','motion_v6 requires SMOKE')
        cmd[1]=str(Path(__file__).with_name('render_smoke_motion.py'))
    if a.variant in ('ports_v8','ports_v9','ports_v10','ports_v11'):
        cmd[1]=str(Path(__file__).with_name('render_smoke_ports.py'))
    if a.variant=='fixed_v5':
        require(m['physics']=='SMOKE','fixed_v5 requires SMOKE')
        cmd[1]=str(Path(__file__).with_name('render_smoke_fixed.py'))
    if a.variant=='combined_v4':
        require(m['physics']=='SMOKE','combined_v4 requires SMOKE')
        cmd[1]=str(Path(__file__).with_name('render_smoke_combined.py'))
    if m['physics']!='SMOKE':
        speedmax=c['visualization']['speed_max_mps']
        if speedmax is None:speedmax=max(x['velocity_mps'] for x in c['levels'].values())*1.5
        cmd+=['--fps',str(fps),'--speed-max',str(speedmax),'--tmin-c',str(c['ambient_c']),'--tmax-c',str(c['heat_initial_c'])]
        if m['physics']=='HEAT':cmd+=['--recovery']
    if a.snapshot:cmd+=['--snapshot']
    # Direct render scripts must use the same tested pvpython environment as
    # cleanbox_pipeline.py (OpenFOAM may override PYTHONPATH/PYTHONHOME).
    from cleanbox_pipeline import paraview_env
    env=paraview_env()
    if m['physics']=='SMOKE':
        require(shutil.which('xvfb-run') and shutil.which('xauth'),
                'SMOKE headless rendering needs: sudo apt-get install xvfb xauth')
        # Preflight runs inside the same Xvfb session as ParaView.
        out.mkdir(parents=True,exist_ok=True)
        env['LIBGL_ALWAYS_SOFTWARE']='1'
        for attempt in range(5):
            xlog=out/('xvfb_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.log')
            wrapped=['xvfb-run','-a','-n',str(100+secrets.randbelow(30000)),
                     '-e',str(xlog),'-s','-screen 0 1920x1080x24 -nolisten tcp',
                     '/usr/bin/python3',str(Path(__file__).with_name('x_display_preflight.py')),*cmd]
            result=subprocess.run(wrapped,env=env)
            if result.returncode==0:break
            if result.returncode!=75:
                raise subprocess.CalledProcessError(result.returncode,wrapped)
            print(f'X startup unavailable ({attempt+1}/5); log: {xlog}',flush=True)
        else:
            raise RuntimeError('X display failed all preflight attempts. No rendering started; inspect xvfb logs.')
    else:
        subprocess.run(cmd,check=True,env=env)
    frames=load(work/'frames.json');require(frames,'No frames')
    shutil.copy2(work/frames[0]['frame'],out/'preview.png');dump(out/'frames.json',frames)
    if a.snapshot:print('Preview:',out/'preview.png');return
    # Smoke renderer exports frames only; legacy flow renderer already encodes.
    source=work/('temperature_recovery.mp4' if m['physics']=='HEAT' else 'airflow_motion.mp4')
    target=out/f'{cid}.mp4'
    if source.exists():shutil.copy2(source,target)
    else:
        subprocess.run(['ffmpeg','-n','-framerate',str(fps),'-i',str(work/'frame_%05d.png'),'-c:v','libx264','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],check=True)
    r=subprocess.run(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames,width,height','-of','json',str(target)],capture_output=True,text=True,check=True)
    import json
    stream=json.loads(r.stdout)['streams'][0]
    require(int(stream['nb_read_frames'])==len(frames),'Encoded frame count mismatch')
    dump(out/'video.json',{'case_id':cid,'video_path':str(target.relative_to(a.root)),'preview_path':str((out/'preview.png').relative_to(a.root)),'frame_count':len(frames),'fps':fps,'mode':'fixed_final_U_illustrative_markers' if a.variant in ('motion_v6','motion_v7','ports_v8','ports_v9','ports_v10','ports_v11') else 'time_varying_C_fixed_final_U' if a.variant=='fixed_v5' else 'illustrative_direction_on_final_field' if m['physics']=='BASE' else 'saved_field_time','flow_basis':m['flow_basis'],'quality':'REVIEW_REQUIRED','frames_retained':True})
    print('Library video:',target)

if __name__=='__main__':main()
