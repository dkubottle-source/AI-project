"""Render HEAT as review-only; never change numerical quality or calculated fields."""
import csv, json, subprocess, shutil
from pathlib import Path
from datetime import datetime
from common import load, dump, verify
from cleanbox_pipeline import paraview_env

def main():
    code=Path(__file__).resolve().parent
    root=code.parent/'pwm_restart_v3'
    out=root/'library'/('heat_fade_legend_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    for tool in ('pvpython','xvfb-run','xauth','ffmpeg','ffprobe'):
        if not shutil.which(tool):raise RuntimeError('Missing tool: '+tool)
    jobs=[]
    for level in ('HIGH','MID','LOW'):
        case=root/'cases'/f'BOTH_HEAT_FAN_{level}_V03';verify(case)
        summary=load(root/'csv'/f'{case.name}_summary.json')
        if not summary.get('solver_complete'):raise RuntimeError('Incomplete: '+case.name)
        if set(summary.get('numerical_failures',[]))-{'temperature_outside_expected_range'}:
            raise RuntimeError('Additional numerical failures: '+case.name)
        jobs.append(case)
    out.mkdir(parents=True,exist_ok=False)
    env=paraview_env();env['LIBGL_ALWAYS_SOFTWARE']='1'
    videos=[]
    for case in jobs:
        target=out/case.name
        cmd=['pvpython',str(code/'render_heat_fade.py'),str(case),'--output',str(target)]
        subprocess.run(['xvfb-run','-a','-e',str(out/(case.name+'_xvfb.log')),
                        '-s','-screen 0 1920x1080x24 -nolisten tcp',
                        '/usr/bin/python3',str(code/'x_display_preflight.py'),*cmd],check=True,env=env)
        video=target/'temperature_recovery.mp4'
        subprocess.run(['ffmpeg','-n','-framerate','20','-i',str(target/'frame_%05d.png'),'-c:v','libx264','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart',str(video)],check=True)
        info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0',
             '-show_entries','stream=nb_read_frames,width,height','-of','json',str(video)]))
        frames=load(target/'frames.json')
        if len(frames)!=1204 or int(info['streams'][0]['nb_read_frames'])!=1204:
            raise RuntimeError('Frame count mismatch: '+case.name)
        dump(target/'video_review.json',dict(case=case.name,quality='REVIEW_REQUIRED',fps=20,
             duration_s=60.2,temperature_scale_C=[24.4,34.3],flow_mode="fixed_final_U_direction_markers",opacity_mapping="linear_local_excess_temperature_alpha_0.48",physical_validation='not_performed'))
        videos.append(video)
    args=['ffmpeg','-n']
    for v in reversed(videos):args+=['-i',str(v)]
    args+=['-filter_complex','[0:v]scale=640:360[a];[1:v]scale=640:360[b];[2:v]scale=640:360[c];[a][b][c]hstack=inputs=3[v]',
           '-map','[v]','-c:v','libx264','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart',str(out/'BOTH_HEAT_LOW_MID_HIGH_REVIEW.mp4')]
    subprocess.run(args,check=True)
    print('HEAT review library:',out,flush=True)

if __name__=='__main__':main()
