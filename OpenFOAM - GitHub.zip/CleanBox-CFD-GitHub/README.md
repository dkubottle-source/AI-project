# CleanBox CFD

OpenFOAM Foundation 14 기반 팬 조건별 유동·온도 회복·수동 추적자 제거 시뮬레이션. Python으로 계산 설정 생성, 실행, CSV 추출 및 영상 생성을 자동화합니다.

## 파일
- `PIPELINE_CONFIG.json`: 팬 유속·온도·계산 시간
- `code/`: OpenFOAM 케이스 생성 및 실행·후처리 코드
- 대용량 계산장과 영상은 제외했습니다. 초기/경계조건과 격자는 generate 명령으로 생성합니다.

## 준비
Ubuntu 또는 WSL에 OpenFOAM Foundation 14, Python 3, ParaView(pvpython), ffmpeg/ffprobe, xvfb, xauth가 필요합니다.

## 실행
저장소 최상위에서 실행합니다. 각 단계 성공 후 다음 단계로 진행하세요.
```bash
source /opt/openfoam14/etc/bashrc
python3 code/cleanbox_pipeline.py doctor
python3 code/cleanbox_pipeline.py generate --mode BOTH
python3 code/cleanbox_pipeline.py run --mode BOTH --physics BASE --skip-pilot
python3 code/cleanbox_pipeline.py post --mode BOTH --physics BASE
```
BASE 완료 후 위 run/post 명령의 BASE를 SMOKE 또는 HEAT로 바꾸어 실행합니다. HEAT/SMOKE는 같은 팬 단계의 BASE 최종 유동장을 초기값으로 사용합니다. --skip-pilot은 사전 시험을 생략합니다. 중단 시 같은 run 명령으로 재개합니다.

HEAT CSV 생성 후 설명용 영상:
```bash
python3 code/render_heat_fade_library.py
```
출력은 `pwm_restart_v3/`에 저장됩니다. 기본 계산 순서는 강풍→중풍→약풍입니다.

## 가정·검증 한계
- 팬 유속 0.87/1.49/2.18 m/s는 추정값이며 설치 상태 실측 유량이 아닙니다.
- BOTH는 등가 입구 유속·출구 압력 모델입니다. 두 팬의 성능곡선을 직접 계산하지 않습니다.
- HEAT 초기 33.91°C, 주변 24.4°C. 단열 벽, 지속 가열·벽 축열 제외.
- SMOKE는 무차원 수동 추적자이며 PM2.5나 가시도가 아닙니다.
- 기존 BOTH HEAT 결과는 초기 국소 온도 초과로 검토 필요 상태입니다. 실험 검증·격자 민감도 검증은 미완료입니다.
- 설명 영상은 대표 유선 고정·시간별 온도 표시이며 마커는 방향 설명용입니다.
- 이 배포본은 코드 검사 대상이며, 전체 CFD 재계산을 수행한 배포본은 아닙니다.

라이선스는 별도로 지정하지 않았습니다. 공개 전 소유자가 재사용 허용 범위를 결정하세요.
