"""Saved tracer slices and instantaneous streamlines; not optical smoke."""
import argparse
import csv
import math
from bisect import bisect_right
from pathlib import Path
from common import load,dump,scheduled_times

def main():
    p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--snapshot',action='store_true');a=p.parse_args()
    from paraview.simple import (MergeBlocks,CellDatatoPointData,CreateView,Show,ColorBy,GetColorTransferFunction,GetScalarBar,ExtractSurface,FeatureEdges,Text,Slice,Calculator,PointSource,StreamTracerWithCustomSource,CreateLayout,SaveScreenshot,SaveState,Sphere,TrivialProducer)
    from paraview import servermanager
    from foam_reader import open_volume
    m=load(a.case/'case.json');out=a.output
    if out.exists() and any(out.iterdir()):raise ValueError('Nonempty output preserved')
    out.mkdir(parents=True,exist_ok=True)
    r=open_volume(a.case/'case.foam',['C','U'])
    data=CellDatatoPointData(Input=MergeBlocks(Input=r));data.UpdatePipeline(time=0)
    # Deep-copy the final velocity field into a timeless producer.
    data.UpdatePipeline(time=m['end'])
    final=servermanager.Fetch(data);frozen=final.NewInstance();frozen.DeepCopy(final)
    representative=TrivialProducer();representative.GetClientSideObject().SetOutput(frozen)
    speed=Calculator(Input=representative);speed.ResultArrayName='Speed_m_s';speed.Function='mag(U)'
    data.UpdatePipeline(time=0)
    view=CreateView('RenderView');views=[view,view]
    layout=CreateLayout(name='Combined concentration and airflow');layout.AssignView(0,view)
    layout.SetSize(1600,900)
    for v in [view]:
        v.Background=[1,1,1]
        if 'UseColorPaletteForBackground' in v.ListProperties():v.UseColorPaletteForBackground=0
        v.CameraFocalPoint=[0,0,.16];v.CameraPosition=[.47,-.82,.47];v.CameraViewUp=[0,0,1];v.CameraParallelProjection=1;v.CameraParallelScale=.32
        edges=FeatureEdges(Input=ExtractSurface(Input=data));edges.ManifoldEdges=0;edges.FeatureEdges=1
        ed=Show(edges,v);ed.ColorArrayName=['POINTS',''];ed.DiffuseColor=[.2,.2,.2];ed.Opacity=1
    lut=GetColorTransferFunction('C');lut.ColorSpace='RGB';lut.RGBPoints=[0,.95,.97,1,.02,.75,.88,1,.05,.35,.7,1,.1,.1,.55,.85,.2,.1,.75,.65,.4,.65,.85,.2,.6,1,.75,.1,.8,1,.35,.05,1,.8,.05,.02];lut.RescaleTransferFunction(0,1)
    for z in [.04,.10,.16,.22,.28]:
        sl=Slice(Input=data);sl.SliceType='Plane';sl.SliceType.Origin=[0,0,z];sl.SliceType.Normal=[0,0,1]
        sd=Show(sl,views[0]);ColorBy(sd,('POINTS','C'));sd.LookupTable=lut;sd.Opacity=.16;sd.Ambient=1;sd.Diffuse=0;sd.SetScalarBarVisibility(views[0],True)
    lut.UseBelowRangeColor=1;lut.BelowRangeColor=[.95,.97,1]
    lut.UseAboveRangeColor=1;lut.AboveRangeColor=[.8,.05,.02]
    # Stable view from above: one slice avoids occlusion by other planes.
    view.CameraParallelScale=.29
    seeds=PointSource();seeds.Center=[0,0,.16];seeds.Radius=.14;seeds.NumberOfPoints=24
    flow=StreamTracerWithCustomSource(Input=speed,SeedSource=seeds);flow.Vectors=['POINTS','U'];flow.IntegrationDirection='FORWARD';flow.MaximumStreamlineLength=.65
    fd=Show(flow,views[1]);ColorBy(fd,('POINTS','Speed_m_s'));fd.LineWidth=2;fd.Opacity=1;fd.SetScalarBarVisibility(views[1],True)
    vmax=m['config']['visualization']['speed_max_mps'] or max(x['velocity_mps'] for x in m['config']['levels'].values())*1.5
    ulut=GetColorTransferFunction('Speed_m_s');ulut.RGBPoints=[0,.1,.2,.8,vmax/2,.1,.8,.4,vmax,.9,.05,.05];ulut.RescaleTransferFunction(0,vmax)
    for v,l,title in [(views[0],lut,'Tracer C (0-1)'),(views[1],ulut,'Speed (m/s)')]:
        bar=GetScalarBar(l,v);bar.Title=title;bar.ComponentTitle='';bar.TitleColor=[0,0,0];bar.LabelColor=[0,0,0];bar.TitleFontSize=13;bar.LabelFontSize=11;bar.WindowLocation='Any Location';bar.Position=[.03 if l==lut else .88,.18];bar.ScalarBarLength=.4
    # Extract paths once; markers never remap onto a changing streamline.
    flow.UpdatePipeline()
    def collect(obj):
        if obj.IsA('vtkMultiBlockDataSet'):
            return [p for n in range(obj.GetNumberOfBlocks()) if obj.GetBlock(n) is not None for p in collect(obj.GetBlock(n))]
        result=[]
        if obj.IsA('vtkPolyData'):
            for n in range(obj.GetNumberOfCells()):
                cell=obj.GetCell(n)
                if cell.GetCellDimension()!=1:continue
                pts=[obj.GetPoint(cell.GetPointId(k)) for k in range(cell.GetNumberOfPoints())]
                clean=[]
                for pt in pts:
                    if not clean or math.dist(clean[-1],pt)>1e-10:clean.append(pt)
                if len(clean)>1:
                    arc=[0.0]
                    for a0,b0 in zip(clean,clean[1:]):arc.append(arc[-1]+math.dist(a0,b0))
                    result.append((clean,arc))
        return result
    paths=collect(servermanager.Fetch(flow))[:12]
    if not paths:raise ValueError('No representative streamlines for moving markers')
    balls=[]
    for pts,arc in paths:
        ball=Sphere();ball.Radius=.0032;ball.Center=pts[0]
        bd=Show(ball,view);bd.ColorArrayName=['POINTS',''];bd.DiffuseColor=[.85,0,.65];bd.Ambient=1;bd.Diffuse=0
        balls.append((ball,bd))
    texts=[]
    for v in [view]:
        tx=Text();td=Show(tx,v);td.Color=[0,0,0];td.FontSize=12;texts.append(tx)
    csvpath=a.case.parent.parent/'csv'/f'{m["case_id"]}_timeseries.csv'
    with csvpath.open(encoding='utf-8-sig') as f:means={round(float(x['time_s']),6):float(x['C_mean']) for x in csv.DictReader(f)}
    times=scheduled_times(r.TimestepValues,m);times=times[:1] if a.snapshot else times;frames=[]
    for i,t in enumerate(times):
        for v in [view]:v.ViewTime=t
        data.UpdatePipeline(time=t)
        texts[0].Text=f'{m["case_id"]} | t={t:g} s | mean C={means[round(t,6)]:.3e}\n5 concentration slices: time varying | streamlines: fixed at t={m["end"]:g}s\nPlayback: 5x | moving dots: direction only, NOT particle speed/time'
        lut.RescaleTransferFunction(0,1);ulut.RescaleTransferFunction(0,vmax)
        # Four display frames per saved field: C is held, never fabricated.
        for sub in range(1 if a.snapshot else 4):
            frame_index=len(frames);video_time=frame_index/20
            for j,((pts,arc),(ball,bd)) in enumerate(zip(paths,balls)):
                distance=(video_time*.04+j*.027)%arc[-1]
                k=min(bisect_right(arc,distance)-1,len(pts)-2)
                f=(distance-arc[k])/(arc[k+1]-arc[k])
                ball.Center=[pts[k][d]*(1-f)+pts[k+1][d]*f for d in range(3)]
                bd.Opacity=min(1,distance/.008,(arc[-1]-distance)/.008)
            name=f'frame_{frame_index:05d}.png';SaveScreenshot(str(out/name),layout,ImageResolution=[1600,900])
            frames.append(dict(frame=name,CFD_time_s=t,video_time_s=video_time,mode='fixed_final_U_illustrative_markers',representative_flow_time_s=m['end'],concentration_sampling='held_saved_field'))
        if i%20==0:print(f'Smoke frame {i+1}/{len(times)}',flush=True)
    dump(out/'frames.json',frames);SaveState(str(out/'cleanbox.pvsm'))

if __name__=='__main__':main()
