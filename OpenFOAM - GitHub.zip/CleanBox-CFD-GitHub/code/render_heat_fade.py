"""Saved tracer slices and instantaneous streamlines; not optical smoke."""
import argparse
import csv
import math
from bisect import bisect_right
from pathlib import Path
from common import load,dump,scheduled_times

def main():
    p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--snapshot',action='store_true');a=p.parse_args()
    from paraview.simple import (MergeBlocks,CellDatatoPointData,CreateView,Show,ColorBy,GetColorTransferFunction,GetScalarBar,ExtractSurface,FeatureEdges,Text,Slice,Calculator,PointSource,StreamTracerWithCustomSource,CreateLayout,SaveScreenshot,SaveState,Sphere,TrivialProducer,OpenFOAMReader,GetOpacityTransferFunction,ForceTime)
    from paraview import servermanager
    from foam_reader import open_volume
    m=load(a.case/'case.json');out=a.output
    if out.exists() and any(out.iterdir()):raise ValueError('Nonempty output preserved')
    out.mkdir(parents=True,exist_ok=True)
    r=open_volume(a.case/'case.foam',['T','U'])
    clocked=ForceTime(Input=r);clocked.IgnorePipelineTime=1;clocked.ForcedTime=0
    data=CellDatatoPointData(Input=MergeBlocks(Input=clocked));data.UpdatePipeline(time=0)
    # Deep-copy the final velocity field into a timeless producer.
    clocked.ForcedTime=m['end']
    data.UpdatePipeline(time=m['end'])
    final=servermanager.Fetch(data);frozen=final.NewInstance();frozen.DeepCopy(final)
    representative=TrivialProducer();representative.GetClientSideObject().SetOutput(frozen)
    speed=Calculator(Input=representative);speed.ResultArrayName='Speed_m_s';speed.Function='mag(U)'
    clocked.ForcedTime=0
    data.UpdatePipeline(time=0)
    heat=Calculator(Input=data);heat.ResultArrayName='Temperature_C';heat.Function='T-273.15'
    view=CreateView('RenderView');views=[view,view]
    layout=CreateLayout(name='Combined concentration and airflow');layout.AssignView(0,view)
    layout.SetSize(1600,900)
    for v in [view]:
        v.Background=[1,1,1]
        if 'UseColorPaletteForBackground' in v.ListProperties():v.UseColorPaletteForBackground=0
        v.CameraFocalPoint=[0,0,.16];v.CameraPosition=[.47,-.82,.47];v.CameraViewUp=[0,0,1];v.CameraParallelProjection=1;v.CameraParallelScale=.32
        edges=FeatureEdges(Input=ExtractSurface(Input=data));edges.ManifoldEdges=0;edges.FeatureEdges=1
        ed=Show(edges,v);ed.ColorArrayName=['POINTS',''];ed.DiffuseColor=[.2,.2,.2];ed.Opacity=1
    ambient=m['config']['ambient_c'];initial=m['config']['heat_initial_c']
    lut=GetColorTransferFunction('Temperature_C');lut.ColorSpace='RGB'
    lut.RGBPoints=[ambient,.85,.08,.03,34.3,.85,.08,.03]
    # Explicit vertex RGBA avoids version-dependent LUT surface opacity behavior.
    from vtkmodules.vtkCommonCore import vtkUnsignedCharArray
    heat_slices=[]
    for z in [.04,.10,.16,.22,.28]:
        sl=Slice(Input=heat);sl.SliceType='Plane';sl.SliceType.Origin=[0,0,z];sl.SliceType.Normal=[0,0,1]
        sl.UpdatePipeline(time=0)
        producer=TrivialProducer()
        heat_slices.append((sl,producer))
    diagnostics=[]
    def update_heat(t):
        clocked.ForcedTime=t
        heat.UpdatePipeline(time=t)
        slice_values=[]
        for sl,producer in heat_slices:
            sl.UpdatePipeline(time=t)
            obj=servermanager.Fetch(sl)
            poly=obj.NewInstance();poly.DeepCopy(obj)
            values=poly.GetPointData().GetArray('Temperature_C')
            if values is None:raise RuntimeError('Temperature_C missing from heat slice')
            slice_values.extend(values.GetTuple1(j) for j in range(poly.GetNumberOfPoints()))
            rgba=vtkUnsignedCharArray();rgba.SetName('HeatRGBA');rgba.SetNumberOfComponents(4)
            for j in range(poly.GetNumberOfPoints()):
                ratio=max(0.0,min(1.0,(values.GetTuple1(j)-ambient)/(initial-ambient)))
                # Square-root enhancement reveals weak residual warmth; same for every case.
                alpha=round(255*0.48*ratio)
                rgba.InsertNextTuple4(220,35,15,alpha)
            poly.GetPointData().AddArray(rgba)
            producer.GetClientSideObject().SetOutput(poly)
            producer.GetClientSideObject().Modified()
            producer.MarkModified(producer)
            producer.UpdatePipeline()
        if not slice_values:raise RuntimeError('Empty temperature slices')
        diagnostics.append(dict(time_s=t,slice_min_C=min(slice_values),slice_max_C=max(slice_values)))
        dump(out/'temperature_render_checks.json',diagnostics)
        if t==m['end'] and max(slice_values)>ambient+1:
            raise RuntimeError('Final heat slices still hot: time update failed; rendering stopped')
    update_heat(m['end'])  # Test the cold endpoint before rendering 1204 frames.
    update_heat(0)
    for sl,producer in heat_slices:
        sd=Show(producer,view);ColorBy(sd,('POINTS','HeatRGBA'))
        sd.MapScalars=0;sd.Opacity=1;sd.Ambient=1;sd.Diffuse=0
        if 'ForceTranslucent' in sd.ListProperties():sd.ForceTranslucent=1
        sd.SetScalarBarVisibility(view,False)
    # Stable view from above: one slice avoids occlusion by other planes.
    view.CameraParallelScale=.29
    seeds=PointSource();seeds.Center=[0,0,.16];seeds.Radius=.14;seeds.NumberOfPoints=32
    flow=StreamTracerWithCustomSource(Input=speed,SeedSource=seeds);flow.Vectors=['POINTS','U'];flow.IntegrationDirection='FORWARD';flow.MaximumStreamlineLength=2.5;flow.MaximumSteps=30000;flow.TerminalSpeed=1e-8
    fd=Show(flow,views[1]);ColorBy(fd,('POINTS','Speed_m_s'));fd.LineWidth=2.5;fd.Opacity=1;fd.SetScalarBarVisibility(views[1],True)
    vmax=m['config']['visualization']['speed_max_mps'] or max(x['velocity_mps'] for x in m['config']['levels'].values())*1.5
    ulut=GetColorTransferFunction('Speed_m_s');ulut.RGBPoints=[0,.1,.2,.8,vmax/2,.1,.8,.4,vmax,.9,.05,.05];ulut.RescaleTransferFunction(0,vmax)
    for v,l,title in [(views[1],ulut,'Speed (m/s)')]:
        bar=GetScalarBar(l,v);bar.Title=title;bar.ComponentTitle='';bar.TitleColor=[0,0,0];bar.LabelColor=[0,0,0];bar.TitleFontSize=13;bar.LabelFontSize=11;bar.WindowLocation='Any Location';bar.Position=[.03 if l==lut else .88,.18];bar.ScalarBarLength=.4
    # Add boundary seeds in the fluid, using the same opposed-wall geometry as BASE.
    ni=m['inlet_normal']
    inlet_seed=[x+.012*n for x,n in zip(m['inlet_center'],ni)]
    outlet_reader=OpenFOAMReader(FileName=str(a.case/'case.foam'))
    outlet_reader.UpdatePipelineInformation()
    outlet_names=[n for n in outlet_reader.MeshRegions.Available if n=='outlet' or n.endswith('/outlet')]
    if not outlet_names:raise ValueError('Boundary patch missing: outlet')
    outlet_reader.MeshRegions=outlet_names;outlet_reader.UpdatePipeline(time=m['end'])
    bounds=outlet_reader.GetDataInformation().GetBounds()
    outlet_seed=[(bounds[2*j]+bounds[2*j+1])/2 for j in range(3)]
    outlet_seed=[outlet_seed[0]-.012*ni[0],outlet_seed[1],outlet_seed[2]+.012*ni[2]]
    boundary_flows=[]
    for center,direction,count in [(inlet_seed,'FORWARD',18),(outlet_seed,'BACKWARD',12)]:
        source=PointSource();source.Center=center;source.Radius=.006;source.NumberOfPoints=count
        tracer=StreamTracerWithCustomSource(Input=speed,SeedSource=source)
        tracer.Vectors=['POINTS','U'];tracer.IntegrationDirection=direction
        tracer.MaximumStreamlineLength=2.5;tracer.MaximumSteps=30000;tracer.TerminalSpeed=1e-8
        tracer.UpdatePipeline()
        display=Show(tracer,view);ColorBy(display,('POINTS','Speed_m_s'))
        display.LookupTable=ulut;display.LineWidth=2.5;display.Opacity=1
        boundary_flows.append((tracer,direction))
    # Extract paths once; markers never remap onto a changing streamline.
    flow.UpdatePipeline()
    def collect(obj):
        if obj.IsA('vtkMultiBlockDataSet'):
            return [p for n in range(obj.GetNumberOfBlocks()) if obj.GetBlock(n) is not None for p in collect(obj.GetBlock(n))]
        result=[]
        if obj.IsA('vtkPolyData'):
            for n in range(obj.GetNumberOfCells()):
                cell=obj.GetCell(n)
                if cell.GetCellDimension()!=1:continue
                pts=[obj.GetPoint(cell.GetPointId(k)) for k in range(cell.GetNumberOfPoints())]
                clean=[]
                for pt in pts:
                    if not clean or math.dist(clean[-1],pt)>1e-10:clean.append(pt)
                if len(clean)>1:
                    arc=[0.0]
                    for a0,b0 in zip(clean,clean[1:]):arc.append(arc[-1]+math.dist(a0,b0))
                    result.append((clean,arc))
        return result
    paths=collect(servermanager.Fetch(flow))[:4]
    for tracer,direction in boundary_flows:
        selected=collect(servermanager.Fetch(tracer))[:4]
        if not selected:raise ValueError('No boundary streamlines: '+direction)
        for pts,arc in selected:
            if direction=='BACKWARD':
                # Trace upstream, but move markers downstream with the actual flow.
                pts=list(reversed(pts));arc=[0.0]
                for a0,b0 in zip(pts,pts[1:]):arc.append(arc[-1]+math.dist(a0,b0))
            paths.append((pts,arc))
    if not paths:raise ValueError('No representative streamlines for moving markers')
    balls=[]
    for pts,arc in paths:
        ball=Sphere();ball.Radius=.004096;ball.Center=pts[0]
        bd=Show(ball,view);bd.ColorArrayName=['POINTS',''];bd.DiffuseColor=[.65,0,.45];bd.AmbientColor=[.65,0,.45];bd.Ambient=1;bd.Diffuse=0
        balls.append((ball,bd))
    # Use the real inlet/outlet patch geometry, with fully opaque solid colors.
    for patch,color in [('inlet',[0.0,0.65,0.1]),('outlet',[0.9,0.1,0.05])]:
        port=OpenFOAMReader(FileName=str(a.case/'case.foam'))
        port.UpdatePipelineInformation()
        names=[n for n in port.MeshRegions.Available if n==patch or n.endswith('/'+patch)]
        if not names:raise ValueError('Boundary patch missing: '+patch)
        port.MeshRegions=names;port.UpdatePipeline(time=m['end'])
        obj=servermanager.Fetch(port);patchcopy=obj.NewInstance();patchcopy.DeepCopy(obj)
        frozenport=TrivialProducer();frozenport.GetClientSideObject().SetOutput(patchcopy)
        pd=Show(frozenport,view);pd.ColorArrayName=['POINTS',''];pd.DiffuseColor=color
        pd.Opacity=1;pd.Ambient=0;pd.Diffuse=1
        pd.AmbientColor=color  # Keep both material colors consistent with BASE.
    # Legend is the appearance of ONE red slice composited over white.
    # It describes opacity, not a second physical temperature color scale.
    legend_lut=GetColorTransferFunction('HeatOpacityLegend')
    legend_lut.ColorSpace='RGB';legend_points=[]
    for fraction in (0,.25,.5,.75,1):
        alpha=.48*fraction
        color=[1-alpha+alpha*c/255 for c in (220,35,15)]
        legend_points.extend([ambient+(initial-ambient)*fraction,*color])
    legend_lut.RGBPoints=legend_points
    legend=GetScalarBar(legend_lut,view);legend.Visibility=1
    legend.Title='Temperature (C)';legend.ComponentTitle=''
    legend.TitleColor=[0,0,0];legend.LabelColor=[0,0,0]
    legend.TitleFontSize=14;legend.LabelFontSize=12
    legend.WindowLocation='Any Location';legend.Position=[.03,.20];legend.ScalarBarLength=.40
    if 'UseCustomLabels' in legend.ListProperties():
        legend.UseCustomLabels=1;legend.CustomLabels=[ambient,ambient+(initial-ambient)*.5,initial]
    note=Text();note.Text='Heat: clear = ambient; red = warm\nLegend: one slice; overlaps appear darker'
    nd=Show(note,view);nd.Color=[0,0,0];nd.FontSize=12;nd.WindowLocation='Lower Left Corner'
    # Record streamline termination codes for review instead of joining endpoints.
    termination={}
    for name,trace in [('interior',flow)]+[(direction,tr) for tr,direction in boundary_flows]:
        obj=servermanager.Fetch(trace)
        codes=obj.GetCellData().GetArray('ReasonForTermination') if hasattr(obj,'GetCellData') else None
        counts={}
        if codes:
            for j in range(codes.GetNumberOfTuples()):
                key=str(int(codes.GetTuple1(j)));counts[key]=counts.get(key,0)+1
        termination[name]=counts
    dump(out/'streamline_termination_codes.json',termination)
    texts=[]
    for v in [view]:
        tx=Text();td=Show(tx,v);td.Color=[0,0,0];td.FontSize=12;texts.append(tx)
    csvpath=a.case.parent.parent/'csv'/f'{m["case_id"]}_timeseries.csv'
    with csvpath.open(encoding='utf-8-sig') as f:means={round(float(x['time_s']),6):float(x['T_mean_C']) for x in csv.DictReader(f)}
    times=scheduled_times(r.TimestepValues,m);times=times[:1] if a.snapshot else times;frames=[]
    for i,t in enumerate(times):
        for v in [view]:v.ViewTime=t
        data.UpdatePipeline(time=t)
        update_heat(t)
        texts[0].Text=(f'{m["case_id"]} | CFD t={t:g}s | mean T={means[round(t,6)]:.2f} C\n'
            f'Red opacity: 0.48*normalized excess T; clear at {ambient:g} C, full reference {initial:g} C\n'
            f'Fixed final flow at {m["end"]:g}s; moving magenta markers: direction ONLY | Playback 5x\n'
            'REVIEW ONLY: initial temperature overshoot; physical validation pending')
        ulut.RGBPoints=[0,.12,.22,.65,vmax/2,.05,.55,.3,vmax,.8,.08,.04]
        ulut.RescaleTransferFunction(0,vmax)
        # Four display frames per saved field: C is held, never fabricated.
        for sub in range(1 if a.snapshot else 4):
            frame_index=len(frames);video_time=frame_index/20
            for j,((pts,arc),(ball,bd)) in enumerate(zip(paths,balls)):
                distance=(video_time*.04+j*.027)%arc[-1]
                k=min(bisect_right(arc,distance)-1,len(pts)-2)
                f=(distance-arc[k])/(arc[k+1]-arc[k])
                ball.Center=[pts[k][d]*(1-f)+pts[k+1][d]*f for d in range(3)]
                bd.Opacity=min(1,distance/.008,(arc[-1]-distance)/.008)
            name=f'frame_{frame_index:05d}.png';SaveScreenshot(str(out/name),layout,ImageResolution=[1600,900])
            frames.append(dict(frame=name,CFD_time_s=t,video_time_s=video_time,mode='fixed_final_U_illustrative_markers',representative_flow_time_s=m['end'],temperature_sampling='held_saved_field'))
        if i%20==0:print(f'Heat frame {i+1}/{len(times)}',flush=True)
    dump(out/'frames.json',frames);SaveState(str(out/'cleanbox.pvsm'))

if __name__=='__main__':main()
