import copy
import tempfile
import unittest
from pathlib import Path
from common import load,PROJECT,validate,verify,merge_function,recovery,saved_times
from case_builder import generate
from common import assess_quality,require_screen,scheduled_times,parse_log_time
from cleanbox_pipeline import run_order

class Tests(unittest.TestCase):
    def config(self):
        c=load(PROJECT/'PIPELINE_CONFIG.json')
        for k,u in zip(c['levels'],(.5,1,1.5)):c['levels'][k]['velocity_mps']=u
        return c

    def test_unset_velocities_block_generation(self):
        c=load(PROJECT/'PIPELINE_CONFIG.json');validate(c,False)
        # Explicitly unset a copy to test the missing-input guard.
        for level in c['levels'].values():level['velocity_mps']=None
        self.assertTrue(all(x['velocity_mps'] is None for x in c['levels'].values()))
        with self.assertRaises(ValueError):validate(c)

    def test_generate_all_physics(self):
        with tempfile.TemporaryDirectory() as d:
            for physics in ('BASE','SMOKE','HEAT'):
                c=self.config();case=Path(d)/physics;m=generate(case,c,physics,'FAN_MID',2,True)
                self.assertEqual(m['case_id'],f'BOTH_{physics}_FAN_MID_{c["revision"]}_PILOT')
                self.assertIn('Cv 1005',(case/'constant/physicalProperties').read_text())
                self.assertEqual((case/'system/blockMeshDict').read_text().count('hex '),25)
                self.assertAlmostEqual(m['patch_area_m2'],.0016)
                self.assertLess(m['inlet_center'][1],0);self.assertGreater(m['outlet_center'][1],0)
                self.assertIn('prghPressure',(case/'0/p_rgh').read_text())
                self.assertIn('purgeWrite 0',(case/'system/controlDict').read_text())
                self.assertEqual(saved_times(case,m)[0][0],0)
                if physics=='HEAT':self.assertIn('-9.81',(case/'constant/g').read_text())
                if physics=='SMOKE':
                    self.assertTrue((case/'0/C').exists());self.assertIn('diffusivity viscosity',(case/'system/controlDict').read_text())
                with self.assertRaises(ValueError):verify(case)
                with self.assertRaises(FileExistsError):generate(case,c,physics,'FAN_MID')

    def test_segment_merge_and_recovery(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for seg,txt in [('0','0 -1\n1 -2\n2 -3\n'),('1','1 -4\n2 -5\n3 -6\n')]:
                p=root/'postProcessing/inletFlux'/seg/'surfaceFieldValue.dat';p.parent.mkdir(parents=True);p.write_text(txt)
            m=merge_function(root,'inletFlux');self.assertEqual(m[1][0],-4);self.assertIn('/1/',m[1][1].replace('\\','/'))
        self.assertEqual(recovery([0,1,2,3],[1,.1,.08,.05],.1,2,1),1)
        self.assertIsNone(recovery([0,1,20],[1,.1,.05],.1,2,1))
        self.assertIsNone(recovery([0,1,2],[1,.8,.7],.1,2,1))

    def test_invalid_physical_config(self):
        for key,value in [('duration_s',float('nan')),('smoke_Sct',0),('mesh_refinement',1.5)]:
            c=self.config();c[key]=value
            with self.assertRaises(ValueError):validate(c)
        c=self.config();c['levels']['FAN_HIGH']['velocity_mps']=.1
        with self.assertRaises(ValueError):validate(c)

    def test_incomplete_saved_field(self):
        with tempfile.TemporaryDirectory() as d:
            case=Path(d)/'case';m=generate(case,self.config(),'BASE','FAN_LOW',2,True)
            p=case/'1';p.mkdir();(p/'U').write_text('partial')
            self.assertEqual([t for t,p in saved_times(case,m)],[0])

    def test_complete_log_and_fields_gate(self):
        import shutil
        with tempfile.TemporaryDirectory() as d:
            case=Path(d)/'case';m=generate(case,self.config(),'BASE','FAN_LOW',2,True)
            for t in ('1','2'):shutil.copytree(case/'0',case/t)
            (case/'log.checkMesh.01').write_text('Mesh OK.\n')
            (case/'log.foamRun.01').write_text('Time = 2\nEnd\n')
            self.assertEqual(verify(case)['status'],'SOLVER_COMPLETE')
            (case/'2/U').write_text('FoamFile { } internalField uniform (0 0 0); boundaryField {')
            with self.assertRaises(ValueError):verify(case)

    def test_fast_levels_first_with_baseline_dependencies(self):
        import json
        with tempfile.TemporaryDirectory() as d:
            cases=[]
            for physics in ('SMOKE','BASE','HEAT'):
                for level in ('FAN_LOW','FAN_MID','FAN_HIGH'):
                    case=Path(d)/(physics+'_'+level);case.mkdir()
                    (case/'case.json').write_text(json.dumps({'physics':physics,'condition_id':level}))
                    cases.append(case)
            self.assertEqual([p.name for p in run_order(cases)],
                             [p+'_'+l for p in ('BASE','SMOKE','HEAT') for l in ('FAN_HIGH','FAN_MID','FAN_LOW')])

    def test_fan_mode_boundaries_and_metadata(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for mode in ('BOTH','INTAKE','EXHAUST'):
                case=root/mode;m=generate(case,self.config(),'BASE','FAN_LOW',2,True,mode)
                self.assertEqual(m['mode'],mode)
                self.assertEqual(m['intake_pwm_percent'],0 if mode=='EXHAUST' else 35)
                self.assertEqual(m['exhaust_pwm_percent'],0 if mode=='INTAKE' else 35)
                u=(case/'0/U').read_text();p=(case/'0/p_rgh').read_text()
                if mode=='EXHAUST':
                    self.assertRegex(u,r'inlet \{ type pressureInletOutletVelocity')
                    self.assertRegex(u,r'outlet \{ type fixedValue')
                    self.assertRegex(p,r'inlet \{ type prghPressure')
                    self.assertRegex(p,r'outlet \{ type fixedFluxPressure')
                else:
                    self.assertRegex(u,r'inlet \{ type fixedValue')
                    self.assertRegex(u,r'outlet \{ type pressureInletOutletVelocity')

    def test_foundation_time_units(self):
        for text,value in [('Time = 0s\n',0),('Time = 1.25 s\n',1.25),('Time = 3e-03s\n',.003),('Time = 300\n',300)]:
            self.assertEqual(parse_log_time(text),value)
        for text in ['ExecutionTime = 10 s','Time = invalid','Time = 2min','Time = 1e999s']:
            self.assertIsNone(parse_log_time(text))

    def test_export_timeline_excludes_pause_checkpoints(self):
        meta={'end':2,'config':{'field_interval_s':1}}
        self.assertEqual(scheduled_times([0,.7,1,1.9,2],meta),[0,1,2])
        with self.assertRaises(ValueError):scheduled_times([0,.7,2],meta)

    def test_quality_blocks_bad_fields_and_unstable_baseline(self):
        meta={'config':self.config(),'config_hash':'test','end':300,'physics':'BASE','pilot':False}
        rows=[dict(time_s=t,T_min_C=24.4,T_max_C=24.4,U_mean_mps=.1,
                   mass_balance_residual_kg_s=0,mdot_inlet_signed_kg_s=-.001,
                   mdot_outlet_signed_kg_s=.001,boundary_imbalance_fraction=0,
                   C_min=0,C_max=1) for t in range(301)]
        result=assess_quality(rows,meta);result['config_hash']='test'
        require_screen(result,meta,True)
        rows[-1]['U_mean_mps']=.2
        result.update(assess_quality(rows,meta))
        with self.assertRaises(ValueError):require_screen(result,meta,True)
        rows[-1]['U_mean_mps']=.1;meta['physics']='SMOKE';rows[-1]['C_min']=-.1
        result.update(assess_quality(rows,meta))
        with self.assertRaises(ValueError):require_screen(result,meta)
        rows[-1]['C_min']=0;rows[-1]['T_max_C']=50
        self.assertIn('temperature_outside_expected_range',assess_quality(rows,meta)['numerical_failures'])
        rows[-1]['T_max_C']=24.4;rows[-1]['mass_balance_residual_kg_s']=.0001
        self.assertIn('tail_mass_balance_review',assess_quality(rows,meta)['numerical_failures'])
        with self.assertRaises(ValueError):require_screen({'config_hash':'old','numerical_screen':'PASS'},meta)

if __name__=='__main__':unittest.main()
