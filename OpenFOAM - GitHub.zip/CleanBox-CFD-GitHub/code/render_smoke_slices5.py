"""Saved tracer slices and instantaneous streamlines; not optical smoke."""
import argparse
import csv
from pathlib import Path
from common import load,dump,scheduled_times

def main():
    p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--snapshot',action='store_true');a=p.parse_args()
    from paraview.simple import (MergeBlocks,CellDatatoPointData,CreateView,Show,ColorBy,GetColorTransferFunction,GetScalarBar,ExtractSurface,FeatureEdges,Text,Slice,Calculator,PointSource,StreamTracerWithCustomSource,CreateLayout,SaveScreenshot,SaveState)
    from foam_reader import open_volume
    m=load(a.case/'case.json');out=a.output
    if out.exists() and any(out.iterdir()):raise ValueError('Nonempty output preserved')
    out.mkdir(parents=True,exist_ok=True)
    r=open_volume(a.case/'case.foam',['C','U'])
    data=CellDatatoPointData(Input=MergeBlocks(Input=r));data.UpdatePipeline(time=0)
    speed=Calculator(Input=data);speed.ResultArrayName='Speed_m_s';speed.Function='mag(U)'
    views=[CreateView('RenderView') for _ in range(6)]
    layout=CreateLayout(name='Five concentration slices and airflow')
    layout.SplitHorizontal(0,1/3);layout.SplitHorizontal(2,.5)
    for cell in (1,5,6):layout.SplitVertical(cell,.5)
    for cell,v in zip((3,11,13,4,12,14),views):layout.AssignView(cell,v)
    layout.SetSize(1920,1080)
    for v in views:
        v.Background=[1,1,1]
        if 'UseColorPaletteForBackground' in v.ListProperties():v.UseColorPaletteForBackground=0
        v.CameraFocalPoint=[0,0,.16];v.CameraPosition=[.47,-.82,.47];v.CameraViewUp=[0,0,1];v.CameraParallelProjection=1;v.CameraParallelScale=.32
        edges=FeatureEdges(Input=ExtractSurface(Input=data));edges.ManifoldEdges=0;edges.FeatureEdges=1
        ed=Show(edges,v);ed.ColorArrayName=['POINTS',''];ed.DiffuseColor=[.2,.2,.2];ed.Opacity=1
    lut=GetColorTransferFunction('C');lut.RGBPoints=[0,.95,.97,1,.25,.2,.65,1,.6,1,.7,.1,1,.8,.05,.02];lut.RescaleTransferFunction(0,1)
    heights=[.04,.10,.16,.22,.28]
    for panel,z in enumerate(heights):
        sl=Slice(Input=data);sl.SliceType='Plane';sl.SliceType.Origin=[0,0,z];sl.SliceType.Normal=[0,0,1]
        sd=Show(sl,views[panel]);ColorBy(sd,('POINTS','C'));sd.LookupTable=lut;sd.Opacity=1;sd.Ambient=1;sd.Diffuse=0;sd.SetScalarBarVisibility(views[panel],True)
    lut.UseBelowRangeColor=1;lut.BelowRangeColor=[.95,.97,1]
    lut.UseAboveRangeColor=1;lut.AboveRangeColor=[.8,.05,.02]
    # Stable view from above: one slice avoids occlusion by other planes.
    for panel,z in enumerate(heights):
        v=views[panel];v.CameraPosition=[0,0,1];v.CameraFocalPoint=[0,0,z];v.CameraViewUp=[0,1,0];v.CameraParallelScale=.25
    seeds=PointSource();seeds.Center=[0,0,.16];seeds.Radius=.14;seeds.NumberOfPoints=24
    flow=StreamTracerWithCustomSource(Input=speed,SeedSource=seeds);flow.Vectors=['POINTS','U'];flow.IntegrationDirection='FORWARD';flow.MaximumStreamlineLength=.65
    fd=Show(flow,views[5]);ColorBy(fd,('POINTS','Speed_m_s'));fd.LineWidth=2;fd.Opacity=1;fd.SetScalarBarVisibility(views[5],True)
    vmax=m['config']['visualization']['speed_max_mps'] or max(x['velocity_mps'] for x in m['config']['levels'].values())*1.5
    ulut=GetColorTransferFunction('Speed_m_s');ulut.RGBPoints=[0,.1,.2,.8,vmax/2,.1,.8,.4,vmax,.9,.05,.05];ulut.RescaleTransferFunction(0,vmax)
    for v,l,title in [(v,lut,'Tracer C (0-1)') for v in views[:5]]+[(views[5],ulut,'Speed (m/s)')]:
        bar=GetScalarBar(l,v);bar.Title=title;bar.ComponentTitle='';bar.TitleColor=[0,0,0];bar.LabelColor=[0,0,0];bar.TitleFontSize=13;bar.LabelFontSize=11
    texts=[]
    for v in views:
        tx=Text();td=Show(tx,v);td.Color=[0,0,0];td.FontSize=12;texts.append(tx)
    csvpath=a.case.parent.parent/'csv'/f'{m["case_id"]}_timeseries.csv'
    with csvpath.open(encoding='utf-8-sig') as f:means={round(float(x['time_s']),6):float(x['C_mean']) for x in csv.DictReader(f)}
    times=scheduled_times(r.TimestepValues,m);times=times[:1] if a.snapshot else times;frames=[]
    for i,t in enumerate(times):
        for v in views:v.ViewTime=t
        data.UpdatePipeline(time=t);flow.UpdatePipeline(time=t)
        for panel,z in enumerate(heights):
            texts[panel].Text=f'{m["condition_id"]} | t={t:g} s | z={z*1000:.0f} mm\nConcentration C: fixed scale 0-1\nBox mean C={means[round(t,6)]:.3e}'
        texts[5].Text='Instantaneous airflow streamlines\nColor: speed | assumed flow\nPassive tracer, not PM2.5 or visibility'
        lut.RescaleTransferFunction(0,1);ulut.RescaleTransferFunction(0,vmax)
        name=f'frame_{i:05d}.png';SaveScreenshot(str(out/name),layout,ImageResolution=[1920,1080])
        frames.append(dict(frame=name,CFD_time_s=t,mode='five_slices_and_instantaneous_streamlines',slice_heights_m=heights))
        if i%20==0:print(f'Smoke frame {i+1}/{len(times)}',flush=True)
    dump(out/'frames.json',frames);SaveState(str(out/'cleanbox.pvsm'))

if __name__=='__main__':main()
